#!/bin/bash
bochs -q
